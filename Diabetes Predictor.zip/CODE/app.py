from flask import Flask, render_template, request, redirect, url_for, flash
import numpy as np
import pickle
import pandas as pd
import os

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Load model and scaler (make sure model.pkl and scaler.pkl exist)
model = pickle.load(open("model.pkl", "rb"))
scaler = pickle.load(open("scaler.pkl", "rb"))

# Optional: file to save prediction history
HISTORY_CSV = "predictions_history.csv"

@app.route("/")
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Read form inputs (strings) and convert to float
        pregnancies = float(request.form.get('pregnancies', 0))
        glucose = float(request.form.get('glucose', 0))
        bloodpressure = float(request.form.get('bloodpressure', 0))
        skinthickness = float(request.form.get('skinthickness', 0))
        insulin = float(request.form.get('insulin', 0))
        bmi = float(request.form.get('bmi', 0))
        dpf = float(request.form.get('dpf', 0))
        age = float(request.form.get('age', 0))

        features = np.array([[pregnancies, glucose, bloodpressure, skinthickness,
                              insulin, bmi, dpf, age]])

        features_scaled = scaler.transform(features)
        prediction = model.predict(features_scaled)[0]
        proba = model.predict_proba(features_scaled)[0][1]

        result_text = "Diabetic" if prediction == 1 else "Not Diabetic"
        proba_text = f"{proba*100:.2f}%"

        # Save history (append)
        try:
            row = {
                'pregnancies': pregnancies,
                'glucose': glucose,
                'bloodpressure': bloodpressure,
                'skinthickness': skinthickness,
                'insulin': insulin,
                'bmi': bmi,
                'dpf': dpf,
                'age': age,
                'prediction': int(prediction),
                'probability': proba
            }
            df_hist = pd.DataFrame([row])
            if not os.path.exists(HISTORY_CSV):
                df_hist.to_csv(HISTORY_CSV, index=False)
            else:
                df_hist.to_csv(HISTORY_CSV, mode='a', header=False, index=False)
        except Exception as e:
            # don't break prediction if history fails
            print('Warning: could not save history:', e)

        return render_template('index.html', prediction=True, result=result_text, probability=proba_text,
                               inputs=row)

    except Exception as e:
        flash('Error processing input: ' + str(e))
        return redirect(url_for('home'))

if __name__ == '__main__':
    app.run(debug=True)